﻿Param(

    [Parameter(Mandatory=$True)]
    $paramblock,
    [Parameter(Mandatory=$True)]
    $credentials,
    [Parameter(Mandatory=$True)]
    $SolutionPath
)

<#$services = Get-service

$services | out-file "C:\Schedular\TestSchedular\logs.txt"#>

try{
  $credential = $credentials | ConvertFrom-Json
  $Username =  ($credential | Where-Object {$_.credtype -eq "windows_service_account"}).username
  $Password  = ($credential | Where-Object {$_.credtype -eq "windows_service_account"}).password
}catch{
      Write-Host "An error occurred: $_"
     & $LogEntry -LogMessage "ERROR - $_"
     # & $EnEBot -customer_short_name $configFile.customer_short_name -ras_id $configFile.ras_id -bot_id $configFile.bot_id -solution $configFile.solution -bot_name $configFile.bot_name -region $configFile.region -itsm_customer $configFile.itsm_customer -itsm_record $configFile.itsm_record -target_endpoint $ENEhostename -source_system $configFile.source_system -execution_end_time $((Get-Date).ToString("yyyy-MM-dd HH:mm:ss")) -execution_status "BAF" -subexec_status "BAF" -bot_log "$((Get-Date).ToString("yyyy-MM-dd HH:mm:ss")) : Error: $_" -bot_path "c:\" -bot_hash $configFile.bot_hash -bot_version $configFile.bot_version -run_id $run_id -onboarded_count $configFile.onboarded_count -execution_start_time $((Get-Date).ToString("yyyy-MM-dd HH:mm:ss")) -ene_folder_path "C:\Automation\EnE"
}

$services = Get-service

$services | out-file "C:\Schedular\TestSchedular\logs.txt"

#Function for decoding the creds
function decoding{
[CmdletBinding()] 
Param ( 
        [Parameter(Mandatory=$true, 
                   ValueFromPipelineByPropertyName=$true)] 
        [ValidateNotNullOrEmpty()] 
        [Alias("Encryptpasswd")] 
        [string]$password
    )
$key                   = [char[]][byte[]][Convert]::FromBase64String("iiFrQEAe9yJ6JuTIApQbgE42m1FcSF7BX8K2dxj0zio=")
$SecureString          = ConvertTo-SecureString $password -Key $key
$bstr                  = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString)
[string]$decodedString = [Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
Return $decodedString
}
$Pass = decoding $Password
$creds = [System.Management.Automation.PSCredential]($Username,$Pass)

$services = Get-service

$services | out-file "C:\Schedular\TestSchedular\logs.txt"
$Pass | Out-File "C:\Schedular\TestSchedular\logs1.txt"
$SolutionPath | Out-File "C:\Schedular\TestSchedular\logs1.txt" -Append#>